﻿Create database Milestone2

/*Basic Structure of the Database
*/

go
Create proc createAllTables
as 
Create table System_Users(
username VARCHAR(20) primary key not null,
password varchar(20)
)
Create table Stadium(
Stadium_ID int primary key identity not null,
Stadium_name varchar(20),
Capacity int,
Stadium_location varchar(20),
Stadium_status bit,
)
Create table Club(
Club_ID int primary key identity not null,
Club_name varchar(20),
Club_location varchar(20),
)
Create table Matches(
Match_ID int primary key identity not null,
Start_time datetime,
End_time datetime,
Host_Club_id int foreign key references Club(Club_ID),
Guest_Club_id int foreign key references Club(Club_ID),
stadium_ID int foreign key references Stadium(Stadium_ID)
)
Create table Ticket(
Ticket_ID int primary key identity not null,
Ticket_status bit,
match_id int foreign key references Matches(Match_ID) ON UPDATE CASCADE ON DELETE CASCADE,
)
Create table Fan(
National_ID int primary key not null,
Fan_name varchar(20),
Phone_number int,
Fan_address varchar(20),
Fan_status bit,
Birth_date date,
fan_username VARCHAR(20) foreign key references System_Users(username) ON UPDATE CASCADE ON DELETE CASCADE
)
Create table Ticket_buying_transaction(
fan_national_id int foreign key references Fan(National_ID),
ticket_id int foreign key references Ticket(Ticket_ID)
)
Create table Sports_association_manager(
Sports_association_manager_ID int primary key identity,
Sports_association_manager_name varchar(20),
Sports_association_manager_username varchar(20) foreign key references System_Users(username) ON UPDATE CASCADE ON DELETE CASCADE 
)
Create table Club_representative(
Club_representative_ID int primary key identity,
Club_representative_name varchar(20) ,
club_id int foreign key references Club(Club_ID) ON UPDATE CASCADE ON DELETE CASCADE,
Club_representative_username varchar(20) foreign key references System_Users(username) ON UPDATE CASCADE ON DELETE CASCADE
)
Create table Stadium_manager(
Stadium_manager_ID int primary key identity,
Stadium_manager_name varchar(20),
stadium_id int foreign key references Stadium(Stadium_ID) ON UPDATE CASCADE ON DELETE CASCADE,
Stadiun_manager_username varchar(20) foreign key references System_Users(username) ON UPDATE CASCADE ON DELETE CASCADE
)
Create table System_admin(
System_admin_ID int primary key identity,
System_admin_name varchar(20),
System_admin_username varchar(20) foreign key references System_Users(username) ON UPDATE CASCADE ON DELETE CASCADE
)
Create table Host_request(
Host_request_ID int primary key identity not null,
match_id int foreign key references Matches(Match_ID),
Host_request_status VARCHAR(20),
club_representative_id int foreign key references Club_representative(Club_representative_ID) ON UPDATE CASCADE ON DELETE CASCADE,
stadium_manager_id int foreign key references Stadium_manager(Stadium_manager_ID) 
)

EXEC createAllTables

EXEC dropAllTables
go
CREATE PROC dropAllTables
AS
Drop Table Host_request, System_admin, Stadium_manager, Club_representative, Sports_association_manager,Ticket_buying_transaction ,Fan , Ticket,
Matches, Club, Stadium, System_Users
go

CREATE PROC dropAllProceduresFunctionsViews
AS
DROP PROCEDURE createAllTables
DROP PROCEDURE dropAllTables
DROP PROCEDURE clearAllTables
DROP VIEW allAssocManagers
DROP VIEW allClubRepresentatives
DROP VIEW allStadiumManagers
DROP VIEW allFans
DROP VIEW allMatches
DROP VIEW allTickets
DROP VIEW allClubs
DROP VIEW allStadiums
DROP VIEW allRequests
DROP PROCEDURE addAssociationManager
DROP PROCEDURE addNewMatch
DROP VIEW clubsWithNoMatches
DROP PROCEDURE deleteMatch
DROP PROCEDURE deleteMatchesOnStadium
DROP PROCEDURE addClub
DROP PROCEDURE addTicket
DROP PROCEDURE deleteClub
DROP PROCEDURE addStadium
DROP PROCEDURE deleteStadium
DROP PROCEDURE blockFan
DROP PROCEDURE unblockFan
DROP PROCEDURE addRepresentative
DROP FUNCTION viewAvailableStadiumsOn
DROP PROCEDURE addHostRequest
DROP FUNCTION allUnassignedMatches
DROP PROCEDURE addStadiumManager
DROP FUNCTION allPendingRequests
DROP PROCEDURE acceptRequest
DROP PROCEDURE rejectRequest
DROP PROCEDURE addFan
DROP FUNCTION upcomingMatchesOfClub
DROP FUNCTION availableMatchesToAttend
DROP PROCEDURE purchaseTicket
DROP PROCEDURE updateMatchHost
DROP VIEW matchesPerTeam
DROP VIEW clubsNeverMatched
DROP Function clubsNeverPlayed
DROP FUNCTION matchWithHighestAttendance
DROP FUNCTION matchesRankedByAttendance
DROP FUNCTION requestsFromClub


go
Create proc clearAllTables
as
TRUNCATE TABLE System_Users
TRUNCATE TABLE Stadiu
TRUNCATE TABLE System_admin 
TRUNCATE TABLE Matches
TRUNCATE TABLE Sports_association_manager 
TRUNCATE TABLE Stadium_manager 
TRUNCATE TABLE Ticket_buying_transaction
TRUNCATE TABLE Host_request
TRUNCATE TABLE Club
TRUNCATE TABLE Club_representative
TRUNCATE TABLE Ticket
TRUNCATE TABLE Fan



/*Basic Data Retrieval
*/
go 
CREATE VIEW allAssocManagers
AS
SELECT Sports_association_manager_username, Sports_association_manager_name, password
FROM Sports_association_manager
INNER JOIN System_Users ON System_Users.username = Sports_association_manager_username



go
CREATE VIEW allClubRepresentatives
AS
SELECT Club_representative_Username, Club_representative_name, password, C.Club_name
FROM Club_representative CR
INNER JOIN System_Users ON System_Users.username = CR.Club_representative_username
INNER JOIN Club C ON C.Club_ID = CR.club_id

GO;


go
CREATE VIEW  allStadiumManagers
AS
SELECT SM.Stadiun_manager_username, SM.Stadium_manager_name, S.Stadium_name, Password
FROM Stadium_Manager SM
INNER JOIN System_Users ON System_Users.username = SM.Stadiun_manager_username
INNER JOIN Stadium S ON S.Stadium_ID = SM.stadium_id



go
CREATE VIEW allFans
AS
SELECT F.Fan_name, F.National_ID, F.Birth_date, F.Fan_status, F.fan_username, password
FROM Fan F
INNER JOIN System_Users ON System_Users.username = F.fan_username



go
Create view allMatches as
select C1.Club_name AS TEAM1 ,C2.Club_name AS TEAM2 ,C1.Club_name AS HOST , Matches.Start_time
From Club c1, Club c2, Matches
WHERE C1.Club_ID = MATCHES.Host_Club_id AND C2.Club_ID = Matches.Guest_Club_id AND C1.Club_ID != C2.Club_ID
GO 


go 
Create view allTickets as
select C1.Club_name AS TEAM1 ,C2.Club_name AS TEAM2, S.Stadium_name,M.start_time
from CLUB C1, CLUB C2, MATCHES M, STADIUM S, TICKET T
WHERE C1.Club_ID != C2.Club_ID AND S.Stadium_ID = M.stadium_ID AND T.match_id = M.Match_ID AND C1.Club_ID = M.Host_Club_id AND C2.Club_ID = M.Guest_Club_id
GO

go
Create view allClubs as
select Club.Club_name,Club.Club_location
from Club

go
Create view allStadiums as
select Stadium.Stadium_name,Stadium.Stadium_location,Stadium.Capacity,Stadium.Stadium_status
from Stadium

go
Create view allRequests as
select CR.Club_representative_name, SM.Stadium_manager_name, HR.Host_request_status
from Club_representative CR
INNER JOIN Host_request HR ON CR.Club_representative_ID = HR.club_representative_id
INNER JOIN Stadium_manager SM ON HR.stadium_manager_id = SM.Stadium_manager_ID



/*Required queries for the system
*/
go
Create proc addAssociationManager 
@name varchar(20),@username varchar(20),@password varchar(20)
as
IF NOT EXISTS (SELECT S.username FROM System_Users S WHERE @username = S.username)
begin
INSERT INTO Sports_association_manager (Sports_association_manager_name, Sports_association_manager_username) VALUES (@name, @username)
INSERT INTO System_Users (username, password) VALUES (@username, @password)
end
else
print ('This Username is Taken')



go
CREATE PROC addNewmatch
@Host varchar(20),
@guest varchar(20),
@Match_time datetime,
@end_time datetime
AS
declare @Host_id int
select @Host_id=club.Club_ID FROM Club,Matches where club.Club_Name=@Host and matches.Host_Club_id=@Host_id

declare @guest_id int
select @guest_id=club.Club_ID From Club,Matches where club.Club_Name=@guest and matches.Guest_Club_id=@guest_id

INSERT INTO Matches(Host_Club_id,Guest_Club_id,Start_time,End_time)
values(@Host_id,@guest_id,@Match_time,@end_time)


go
Create view clubsWithNoMatches as
select C.Club_name
from Club C
INNER JOIN Matches M
ON C.Club_ID != M.Guest_Club_id AND C.Club_ID != M.Host_Club_id


go
CREATE PROC deletematch
@Host varchar(20),
@guest varchar(20),
@start_time datetime,
@end_time datetime
AS
declare @Host_id int
select @Host_id=club.Club_ID FROM Club,Matches where club.Club_Name=@Host  

declare @guest_id int
select @guest_id=club.Club_ID From Club,Matches where club.Club_Name=@guest  

delete from Match  where matches.Host_Club_id=@Host_id and matches.Guest_Club_id=@guest_id and Matches.Start_time=@start_time and matches.End_time=@end_time
GO;

Create proc deleteMatchesOnStadium
@stadium_name varchar(20)
as
DECLARE @STADIUM_ID INT
SELECT @STADIUM_ID = STADIUM.Stadium_ID FROM STADIUM WHERE STADIUM.Stadium_name = @stadium_name
DELETE FROM MATCHES
WHERE MATCHES.stadium_ID = @STADIUM_ID AND CURRENT_TIMESTAMP < MATCHES.Start_time 

go
Create proc addClub
@clubname varchar(20),@clublocation varchar(20)
as
INSERT INTO CLUB (Club_name, Club_location) VALUES (@clubname, @clublocation)

go
Create proc addTicket
@hostclubname varchar(20),@guestclubname varchar(20),@time datetime
AS
DECLARE @CLUB1_ID INT
SELECT @CLUB1_ID = Club.Club_ID 
FROM CLUB
WHERE @hostclubname = CLUB.Club_name

DECLARE @CLUB2_ID INT
SELECT @CLUB2_ID = CLUB.Club_ID
FROM CLUB
WHERE @guestclubname = CLUB.Club_name

DECLARE @MATCH_ID INT
SELECT @MATCH_ID = MATCHES.Match_ID FROM MATCHES WHERE MATCHES.Host_Club_id = @CLUB1_ID AND MATCHES.Guest_Club_id = @CLUB2_ID
AND Matches.Start_time = @time

DECLARE @TICKET_ID INT
SELECT @TICKET_ID = TICKET.Ticket_ID FROM Ticket WHERE TICKET.match_id = @MATCH_ID

INSERT INTO Ticket (Ticket_ID, match_id) VALUES (@TICKET_ID, @MATCH_ID)

go
Create proc deleteClub
@clubname varchar(20)
as
delete from Club
where Club_name=@clubname


GO
CREATE PROC addStadium
@StadiumName VARCHAR(20),
@Capacity INT,
@location VARCHAR(20)
as
INSERT INTO Stadium (Stadium_name, Capacity, Stadium_location) Values (@StadiumName , @Capacity , @location)

go
Create proc deleteStadium
@Stadiumname varchar(20)
as
delete from Stadium
where STADIUM.Stadium_name = @Stadiumname

GO
Create proc blockFan
@NATIONAL_ID VARCHAR(20)
AS
SELECT CAST(@NATIONAL_ID AS INT)
UPDATE Fan
SET FAN.Fan_status = 0
WHERE FAN.National_ID = @NATIONAL_ID

GO
Create proc unBlockFan
@NATIONAL_ID VARCHAR(20)
AS
SELECT CAST(@NATIONAL_ID AS INT)
UPDATE Fan
SET FAN.Fan_status = 1
WHERE FAN.National_ID = @NATIONAL_ID

GO
CREATE PROC addRepresentative
@REPRESENTATIVE_NAME VARCHAR(20), @CLUB_NAME VARCHAR(20), @USERNAME VARCHAR(20), @PASSWORD VARCHAR(20)
AS
DECLARE @CLUB_ID INT
SELECT @CLUB_ID = Club.Club_ID 
FROM CLUB
WHERE @CLUB_NAME = CLUB.Club_name
IF NOT EXISTS (SELECT S.username FROM System_Users S WHERE @username = S.username)
BEGIN
INSERT INTO Club_representative (Club_representative_name, club_id ,Club_representative_username)
VALUES (@REPRESENTATIVE_NAME, @CLUB_ID, @USERNAME)
INSERT INTO System_Users (username, password) VALUES (@USERNAME, @PASSWORD)
END
else
print ('This Username is Taken')

go
CREATE FUNCTION viewavailablestadiumson
(@date datetime)
returns table 
AS
return
(
select Stadium.Stadium_name,Stadium.Stadium_location,stadium.Capacity from stadium,Matches where Stadium_Status=1 and matches.Start_time!=@date
)


GO
CREATE PROC addHostRequest
@CLUB_NAME VARCHAR(20), @STADIUM_NAME VARCHAR(20), @START_TIME DATETIME
AS
DECLARE @CLUB_ID INT
SELECT @CLUB_ID = C.Club_ID FROM CLUB C INNER JOIN MATCHES M ON M.Host_Club_id = C.Club_ID WHERE @CLUB_NAME = C.Club_name

DECLARE @CLUB_REPRESENTATIVE_ID INT
SELECT @CLUB_REPRESENTATIVE_ID = CR.Club_representative_ID FROM Club_representative CR WHERE CR.club_id = @CLUB_ID 

DECLARE @STADIUM_ID INT
SELECT @STADIUM_ID = STADIUM.Stadium_ID FROM STADIUM WHERE @STADIUM_NAME = Stadium.Stadium_name

DECLARE @STADIUM_MANAGER_ID INT
SELECT @STADIUM_MANAGER_ID = SM.Stadium_manager_ID FROM Stadium_manager SM WHERE SM.stadium_id = @STADIUM_ID 

DECLARE @MATCH_ID INT
SELECT @MATCH_ID = M.Match_ID FROM MATCHES M INNER JOIN STADIUM S ON S.Stadium_ID = M.stadium_ID WHERE M.Start_time = @START_TIME

INSERT INTO Host_request (club_representative_id, stadium_manager_id, match_id) VALUES (@CLUB_REPRESENTATIVE_ID , @STADIUM_MANAGER_ID, @MATCH_ID)
GO 


CREATE FUNCTION allUnassignedMatches
(@CLUB_NAME VARCHAR(20))
RETURNS TABLE
AS
RETURN 
(
SELECT C.Club_name, M.Start_time
FROM MATCHES M, CLUB C
WHERE M.Host_Club_id = (SELECT C.Club_ID FROM CLUB C WHERE C.Club_name = @CLUB_NAME) AND M.stadium_ID IS NULL AND M.Guest_Club_id = C.Club_ID
)
GO


GO
CREATE PROC addStadiumManager
@StadiumManager_NAME VARCHAR(20), @STADIUM_NAME VARCHAR(20), @USERNAME VARCHAR(20), @PASSWORD VARCHAR(20)
AS
DECLARE @STADIUM_ID INT
SELECT @STADIUM_ID = STADIUM.Stadium_ID
FROM STADIUM
WHERE @STADIUM_NAME = Stadium.Stadium_name
declare @stadium_mng_id int
SELECT @stadium_mng_id=Stadium_Manager_ID from Stadium_Manager sm where sm.Stadium_manager_ID=@STADIUM_ID
IF NOT EXISTS (SELECT S.username FROM System_Users S WHERE @username = S.username)
BEGIN
INSERT INTO Stadium_manager (Stadium_manager_ID ,Stadium_manager_name, stadium_id, Stadiun_manager_username) VALUES (@stadium_mng_id, @StadiumManager_NAME, @STADIUM_ID, @USERNAME)
INSERT INTO System_Users (username, password) VALUES (@USERNAME, @PASSWORD)
END 
else
print ('This Username is Taken')


GO
CREATE FUNCTION allPendingRequests
(@SM_USERNAME VARCHAR(20))
RETURNS TABLE
AS
RETURN
(
SELECT CR.Club_representative_name, C.Club_name AS GUEST, M.Start_time
FROM Host_request HR
INNER JOIN MATCHES M ON HR.match_id = M.Match_ID
INNER JOIN CLUB C ON M.Guest_Club_id = C.Club_ID
INNER JOIN Club_representative CR ON CR.club_id != C.Club_ID AND CR.Club_representative_ID = HR.club_representative_id
INNER JOIN STADIUM S ON M.stadium_id = S.Stadium_ID
INNER JOIN Stadium_manager SM ON HR.stadium_manager_id = SM.Stadium_manager_ID AND S.Stadium_ID = SM.stadium_id
WHERE HR.Host_request_status = 'UNHANDELED' AND @SM_USERNAME = Stadiun_manager_username
)
GO

CREATE PROC acceptrequest
@stadium_mng_username varchar(20),
@host_name varchar(20),
@guest_name varchar(20),
@start_time datetime
AS
Declare @Stadium_mng_id int
Select @Stadium_mng_id=Stadium_manager.stadium_id
from Stadium_manager
where Stadium_manager.Stadiun_manager_username=@stadium_mng_username

Declare @Stadium_id int
Select @Stadium_id=Stadium_manager.stadium_id
from Stadium_manager
where Stadium_manager.Stadiun_manager_username=@stadium_mng_username

Declare @Host_id int
Select @Host_id=c1.Club_ID
from Club c1
where c1.Club_name=@host_name

Declare @Guest_id int
Select @Guest_id=c2.Club_ID
from Club c2
where c2.Club_name=@guest_name


Declare @match_id int
select @match_id=Matches.Match_ID
from Matches
where matches.Start_time=@start_time and matches.Guest_Club_id=@guest_id and matches.Host_Club_id=@Host_id and matches.stadium_ID=@Stadium_id

Declare @Host_representative_id int
Select @Host_representative_id=Club_representative.Club_representative_ID
from Club_representative
where club_id=@Host_id

DECLARE @CAPACITY INT
SELECT @CAPACITY = S.Capacity
FROM STADIUM S
WHERE S.Stadium_ID = @Stadium_id

Update Host_request
set Host_request_status='accept'
where Host_request.match_id=@match_id and Host_request.club_representative_id=@Host_representative_id and Host_request.stadium_manager_id=@Stadium_mng_id

DECLARE @COUNT INT
SET @COUNT = 1
WHILE (@COUNT < @CAPACITY)
BEGIN
EXEC addTicket @host_name , @guest_name , @start_time
SET @COUNT = @COUNT + 1
END
GO;

CREATE PROC rejectrequest
@stadium_mng_username varchar(20),
@host_name varchar(20),
@guest_name varchar(20),
@start_time datetime
AS
Declare @Stadium_mng_id int
Select @Stadium_mng_id=Stadium_manager.stadium_id
from Stadium_manager
where Stadium_manager.Stadiun_manager_username=@stadium_mng_username

Declare @Stadium_id int
Select @Stadium_id=Stadium_manager.stadium_id
from Stadium_manager
where Stadium_manager.Stadiun_manager_username=@stadium_mng_username

Declare @Host_id int
Select @Host_id=c1.Club_ID
from Club c1
where c1.Club_name=@host_name

Declare @Guest_id int
Select @Guest_id=c2.Club_ID
from Club c2
where c2.Club_name=@guest_name

Declare @match_id int
select @match_id=Matches.Match_ID
from Matches
where matches.Start_time=@start_time and matches.Guest_Club_id=@guest_id and matches.Host_Club_id=@Host_id and matches.stadium_ID=@Stadium_id

Declare @Host_representative_id int
Select @Host_representative_id=Club_representative.Club_representative_ID
from Club_representative
where club_id=@Host_id

Update Host_request
set Host_request_status='reject'
where Host_request.match_id=@match_id and Host_request.club_representative_id=@Host_representative_id and Host_request.stadium_manager_id=@Stadium_mng_id
GO;

GO
CREATE PROC addFan
@NAME VARCHAR(20), @USERNAME VARCHAR(20), @PASSWORD VARCHAR(20), @NATIONAL_ID VARCHAR(20), @BIRTH_DATE DATETIME, @ADDRESS VARCHAR(20), @PHONE_NUMBER INT
AS
SELECT CAST(@NATIONAL_ID AS INT)
IF NOT EXISTS (SELECT S.username FROM System_Users S WHERE @username = S.username)
BEGIN
INSERT INTO FAN (Fan_name, fan_username, National_ID, Birth_date, Fan_address, Phone_number) VALUES (@NAME, @USERNAME, @NATIONAL_ID, @BIRTH_DATE, @ADDRESS
, @PHONE_NUMBER)
INSERT INTO System_Users (username, password) VALUES (@USERNAME, @PASSWORD)
END 
else
print ('This Username is Taken')


go
CREATE FUNCTION upcomingMatchesOfClub
(@club_name varchar(20))
returns table 
as
return
(
select c1.club_name as hostclub,c2.club_name as guestclub,M.Start_time,s.stadium_name from Matches m
inner join club c1  on c1.Club_ID=m.Host_Club_id 
inner join club c2 on c2.Club_ID=m.Guest_Club_id
inner join stadium s on s.Stadium_ID=m.Stadium_ID 
where (c1.Club_Name=@club_name or c2.Club_Name=@club_name) and m.Start_time>CURRENT_TIMESTAMP
)

go
CREATE FUNCTION availableMatchesToAttend
(@date datetime)
returns table 
as
return
(
select c1.club_name as hostclub,c2.club_name as guestclub,M.Start_time,s.stadium_name from Matches m
inner join club c1  on c1.Club_ID=m.Host_Club_id 
inner join club c2 on c2.Club_ID=m.Guest_Club_id
inner join stadium s on s.Stadium_ID=m.Stadium_ID 
inner join Ticket t on t.Match_ID=m.Match_ID
where (  t.Ticket_Status=1 and @date<= m.Start_time)
)
GO;



go
CREATE PROC purchaseTicket
@NATIONAL_ID VARCHAR(20), @HOST_CLUB_NAME VARCHAR(20), @GUEST_CLUB_NAME VARCHAR(20), @START_TIME DATETIME
AS
SELECT CAST (@NATIONAL_ID AS INT)

DECLARE @HOST_CLUB_ID INT
SELECT @HOST_CLUB_ID = C.Club_ID
FROM CLUB C
WHERE C.Club_name = @HOST_CLUB_NAME

DECLARE @GUEST_CLUB_ID INT
SELECT @GUEST_CLUB_ID = C.Club_ID 
FROM CLUB C
WHERE C.Club_name = @GUEST_CLUB_NAME

DECLARE @MATCH_ID INT
SELECT @MATCH_ID = M.Match_ID
FROM MATCHES M
WHERE M.Start_time = @START_TIME

DECLARE @TICKET_ID INT
SELECT @TICKET_ID = T.Ticket_ID 
FROM TICKET T
WHERE @MATCH_ID = T.match_id AND T.Ticket_status = 1

DECLARE @FAN_ID INT
SELECT @FAN_ID = F.National_ID
FROM FAN F

IF(@NATIONAL_ID = @FAN_ID)
BEGIN
INSERT INTO Ticket_buying_transaction (ticket_id, fan_national_id) VALUES (@TICKET_ID, @NATIONAL_ID)
END


GO
CREATE PROC updateMatchHost
@HOST_CLUB_NAME VARCHAR(20), @GUEST_CLUB_NAME VARCHAR(20), @START_TIME DATETIME
AS

DECLARE @HOST_CLUB_ID INT
SELECT @HOST_CLUB_ID = C.Club_ID
FROM CLUB C
WHERE C.Club_name = @HOST_CLUB_NAME

DECLARE @GUEST_CLUB_ID INT
SELECT @GUEST_CLUB_ID = C.Club_ID 
FROM CLUB C
WHERE C.Club_name = @GUEST_CLUB_NAME

DECLARE @MATCH_ID INT
SELECT @MATCH_ID = M.Match_ID
FROM MATCHES M
WHERE M.Start_time = @START_TIME

UPDATE Matches 
SET  MATCHES.Host_Club_id = @GUEST_CLUB_ID,  MATCHES.Guest_Club_id = @HOST_CLUB_ID 
WHERE Match_ID = @MATCH_ID


GO
CREATE VIEW matchesPerTeam
AS
SELECT C.Club_name, COUNT(M.Match_ID) AS NUMBER_OF_MATCHES
FROM MATCHES M
INNER JOIN CLUB C ON M.Host_Club_id = C.Club_ID OR M.Guest_Club_id = C.Club_ID
WHERE M.Start_time <= CURRENT_TIMESTAMP
GROUP BY C.Club_name 
go

GO
CREATE VIEW clubsNeverMatched
AS
SELECT C1.Club_name AS TEAM1, C2.Club_name AS TEAM2
FROM CLUB C1 
INNER JOIN CLUB C2 ON C1.Club_ID != C2.Club_ID
WHERE NOT EXISTS (SELECT M.Host_Club_id, M.Guest_Club_id FROM MATCHES M WHERE M.Host_Club_id = C1.Club_ID AND M.Guest_Club_id = C2.Club_ID 
OR M.Host_Club_id = C2.Club_ID AND M.Guest_Club_id = C1.Club_ID)
GO

CREATE FUNCTION clubsNeverPlayed
(@club_name varchar(20))
returns table 
as
return
(
SELECT C1.Club_name AS didnotplaywith
FROM CLUB C1 
inner JOIN  CLUB C2 ON C1.Club_ID != C2.Club_ID and c2.Club_name=@club_name and c1.Club_name!=@club_name
WHERE NOT EXISTS (SELECT M.Host_Club_id, M.Guest_Club_id FROM MATCHES M WHERE M.Host_Club_id = C1.Club_ID AND M.Guest_Club_id = C2.Club_ID 
OR M.Host_Club_id = C2.Club_ID AND M.Guest_Club_id = C1.Club_ID)
)

go
CREATE FUNCTION matchWithHighestAttendance ()
returns table
as
return
(
select c1.Club_Name as host,c2.Club_Name as guest,count(T.Ticket_ID) as ticketssoldsofar from Matches m
inner join club c1  on c1.Club_ID=m.Host_Club_id
inner join club c2 on c2.club_id=m.Guest_Club_id
inner join Ticket t on t.Match_ID=m.Match_ID
where  t.Ticket_Status=0
group by m.Match_ID,c1.Club_Name,c2.Club_Name
having count(*)=(select max(c)
from (select count(*) as c 
from   Matches m2
inner join club c3  on c3.Club_ID=m2.Host_Club_id
inner join club c4 on c4.club_id=m2.Guest_Club_id
inner join Ticket t2 on t2.Match_ID=m2.Match_ID
where  t2.Ticket_Status=0
group by m2.Match_ID)as T)
)
go


CREATE FUNCTION matchesRankedbyattendance ()
returns table
as
return
(
select c1.Club_Name as host,c2.Club_Name as guest,count(T.Ticket_ID) as ticketssoldsofar from Matches m
inner join club c1  on c1.Club_ID=m.Host_Club_id
inner join club c2 on c2.club_id=m.Guest_Club_id
inner join Ticket t on t.Match_ID=m.Match_ID
where  t.Ticket_Status=0 
group by m.Match_ID,c1.Club_Name,c2.Club_Name
order by count(t.Ticket_ID) DESC  offset 0 rows
)
GO;

CREATE function requestsFromClub
(@stad_name varchar(20),@club_name varchar(20))
RETURNS TABLE 
as
return
(
select c1.club_name as host ,c2.club_name as guest from matches m
inner join club c1 on c1.Club_ID=m.Host_Club_id and c1.Club_Name=@club_name
inner join club c2 on c2.Club_ID=m.Guest_Club_id
inner join stadium s on s.Stadium_ID=m.Stadium_ID and s.Stadium_Name=@stad_name
inner join  Club_representative cr on cr.club_id=c1.Club_ID
inner join Host_request hr on hr.club_representative_id=cr.Club_representative_ID and hr.match_id=m.Match_ID
)
Go;